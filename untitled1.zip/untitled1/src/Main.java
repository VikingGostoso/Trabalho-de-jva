import java.sql.SQLOutput;

public class Main{

    String modelo;
    String marca;
    String placa;
    String cidade;
    String uf ;
    String endereço;
    int anofabricação;
    double valor;
    String telefone;
    String caminhoArquivo;


    public void listagem(){
        System.out.println("==== INÍCIO ====");
        System.out.println("Modelo: " +modelo);
        System.out.println("Marca: " +marca);
        System.out.println("Placa: " +placa);
        System.out.println("Valor: " +valor);
        System.out.println("Ano de Fabricação: " +anofabricação);
        System.out.println("Telefone de contato: " +telefone);
        System.out.println("Cidade: " +cidade);
        System.out.println("Estado: " +uf);
        System.out.println("Endereço: " +endereço);
        System.out.println("Imagem: " +caminhoArquivo);
        System.out.println("==== FIM ====");
    }
}