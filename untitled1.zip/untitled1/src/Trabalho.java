import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.*;
import java.io.File;







public class Trabalho{
    public static void main(String[] args) throws IOException {
        Scanner leitura = new Scanner(System.in);
        ArrayList<Main> listaObjetos = new ArrayList<>();

        char opcao = 0;


        while(opcao != 'X'){

            System.out.println("Digite C para nova cadastro");
            System.out.println("Digite M para listar cadastros");
            System.out.println("Digite X para encerrar");
            opcao = leitura.nextLine().charAt(0);
            System.out.println("Opção selecionada: " + opcao);

            if(opcao == 'C') {

                System.out.println("Novo cadastro de veiculo");
                Main cm = new Main();

                System.out.println("Modelo do veiculo: ");
                cm.modelo = leitura.nextLine();

                System.out.println("Marca do veiculo: ");
                cm.marca = leitura.nextLine();

                System.out.println("Placa do veiculo: ");
                cm.placa = leitura.nextLine();

                System.out.println("Cidade: ");
                cm.cidade = leitura.nextLine();

                System.out.println("Estado: ");
                cm.uf = leitura.nextLine();

                System.out.println("Endereco: ");
                cm.endereço = leitura.nextLine();

                Scanner input = new Scanner(System.in);
                System.out.println("Ano de Fabricação: (0000)\n");
                cm.anofabricação = input.nextInt();

                while  (String.valueOf(cm.anofabricação).length() != 4) // = 4 digitos
                {
                    System.out.print("O ano de fabricação precisa ter quatro digitos:\n");
                    System.out.print("Digite novamente: ");
                    cm.anofabricação = input.nextInt();
                }//fim while



                System.out.println("Valor do veiculo: ");
                cm.valor = leitura.nextDouble();

                Scanner ler = new Scanner(System.in);
                System.out.printf("Informe telefone para contato: (00 000000000)\n");
                cm.telefone= ler.nextLine();

                String ddd = cm.telefone.substring (0,2);
                String fone1 = cm.telefone.substring (3,8);
                String fone2 = cm.telefone.substring (8,12);

                cm.telefone = "(" + ddd + ")" + fone1 + "-" + fone2;
                System.out.println(cm.telefone);
                leitura.nextLine();

                System.out.println("Insira imagem: ");
                JFileChooser jFileChooser = new JFileChooser();
                int respostaDoFileChooser = jFileChooser.showOpenDialog(null);
                String caminhoArquivo = cm.caminhoArquivo;
                if (respostaDoFileChooser == JFileChooser.APPROVE_OPTION){
                    File arquivoSelecionado;
                    arquivoSelecionado = jFileChooser.getSelectedFile();
                    System.out.println("Caminho do arq" + arquivoSelecionado.getAbsolutePath());
                    caminhoArquivo = arquivoSelecionado.getAbsolutePath();
                    System.out.println("Imagem salva");
                    cm.caminhoArquivo = caminhoArquivo;
                } else {
                    System.out.println("Nenhum arquivo selecionado");
                }

                listaObjetos.add(cm);
            }



            else if(opcao == 'M'){
                System.out.println("Imprimindo conteúdo da lista");
                for(int i = 0; i< listaObjetos.size(); i++){
                    listaObjetos.get(i).listagem();
                }
            }
            else{
                System.out.println("Opção inválida");
            }
        }
        System.out.println("Você escolheu encerrar o programa. Pressione qualquer tecla para fechar");
        leitura.nextLine();
        System.exit(0);
    }
}